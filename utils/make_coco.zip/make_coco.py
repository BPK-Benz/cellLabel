import os
import cv2

root = './'
images_path = os.path.join(root, "images")

# label: info
def add_info():
	return {
    	"description": "The cell segmentation tool for P'Benz.",
    	"url": "",
    	"version": "1.0",
    	"year": 2021,
    	"contributor": "AIMLab",
    	"date_created": "2021/03/29",
	}

# label: licenses
def add_licenses():
	return [
		{
			"url": "",
			"id": 1,
			"name": "AIMLab, Mahidol U.",
		}
	]

# label: categories
def add_categories():
	return [
		{
			"supercategory": 'bacteria',
			"id": 1,
			"name": 'bacteria',
		},
		{
			"supercategory": 'nucleus',
			"id": 2,
			"name": 'nucleus',
		},
		{
			"supercategory": 'cell',
			"id": 3,
			"name": 'cell',
		}
	]

# label: categories
def add_categories_detailed():
	return [
		{
			"supercategory": 'cell',
			"id": 1,
			"name": 'cell_complete',
		},
		{
			"supercategory": 'cell',
			"id": 2,
			"name": 'cell_divide',
		},
		{
			"supercategory": 'cell',
			"id": 3,
			"name": 'cell_border',
		},
		{
			"supercategory": 'nucleus',
			"id": 4,
			"name": 'nucleus_complete',
		},
		{
			"supercategory": 'nucleus',
			"id": 5,
			"name": 'nucleus_divide',
		},
		{
			"supercategory": 'nucleus',
			"id": 6,
			"name": 'nucleus_border',
		},
	]